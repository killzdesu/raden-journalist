import asyncio
import logging
from database.db import init_db, save_article, log_run
from fetchers.pubmed import fetch_recent_articles
from processors.filter import filter_new_articles
from summarizer.llm import summarize_article
from notifier.discord import send_header, send_article
from config import MAX_ARTICLES_PER_RUN

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)

async def main():
    logging.info("Starting Research Digest Run")
    init_db()
    
    try:
        # 1. Fetch
        logging.info("Fetching articles from PubMed...")
        all_articles = await fetch_recent_articles()
        logging.info(f"Found {len(all_articles)} raw matching articles before deduplication.")
        
        # 2. Filter / Deduplicate
        new_articles = filter_new_articles(all_articles)
        logging.info(f"After deduplication: {len(new_articles)} new articles to process.")
        
        if len(new_articles) > MAX_ARTICLES_PER_RUN:
            logging.info(f"Limiting to {MAX_ARTICLES_PER_RUN} articles for this run.")
            new_articles = new_articles[:MAX_ARTICLES_PER_RUN]
            
        if not new_articles:
            logging.info("No new articles. Logging and exiting.")
            log_run(len(all_articles), 0, "success (0 new)")
            return
            
        # 3. Process & Summarize & Send
        await send_header(len(new_articles))
        await asyncio.sleep(1.5) # Initial delay
        
        sent_count = 0
        for article in new_articles:
            logging.info(f"Processing PMID: {article['pmid']}")
            
            # Request LLM Summary
            summary = await summarize_article(article)
            
            # Send to Discord
            await send_article(article, summary)
            
            # Save to DB
            save_article(
                pmid=article["pmid"],
                doi=article["doi"],
                title=article["title"],
                journal=article["journal"],
                pub_date=article["pub_date"]
            )
            
            sent_count += 1
            await asyncio.sleep(1.5) # Standard Discord webhook tolerance
            
        log_run(len(all_articles), sent_count, "success")
        logging.info(f"Run complete. Processed {sent_count} articles.")
        
    except Exception as e:
        logging.error(f"Fatal run error: {e}", exc_info=True)
        log_run(0, 0, f"error: {str(e)[:50]}")

if __name__ == "__main__":
    asyncio.run(main())
