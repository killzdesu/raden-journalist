import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "digest.db")

def get_connection():
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pmid TEXT UNIQUE,
            doi TEXT,
            title TEXT,
            journal TEXT,
            pub_date TEXT,
            fetched_at DATETIME,
            sent INTEGER DEFAULT 0
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS run_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_date TEXT,
            articles_found INTEGER,
            articles_sent INTEGER,
            status TEXT,
            created_at DATETIME
        )
    ''')
    
    conn.commit()
    conn.close()

def article_exists(pmid: str) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM articles WHERE pmid = ?", (pmid,))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

def save_article(pmid: str, doi: str, title: str, journal: str, pub_date: str):
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    try:
        cursor.execute('''
            INSERT INTO articles (pmid, doi, title, journal, pub_date, fetched_at, sent)
            VALUES (?, ?, ?, ?, ?, ?, 0)
        ''', (pmid, doi, title, journal, pub_date, now))
        conn.commit()
    except sqlite3.IntegrityError:
        pass # Already exists
    finally:
        conn.close()

def mark_article_sent(pmid: str):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE articles SET sent = 1 WHERE pmid = ?", (pmid,))
    conn.commit()
    conn.close()

def log_run(articles_found: int, articles_sent: int, status: str):
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    run_date = datetime.utcnow().strftime("%Y-%m-%d")
    cursor.execute('''
        INSERT INTO run_logs (run_date, articles_found, articles_sent, status, created_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (run_date, articles_found, articles_sent, status, now))
    conn.commit()
    conn.close()
