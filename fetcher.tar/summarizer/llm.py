import logging
import httpx
from config import KKU_API_KEY, LLM_PROVIDER, LLM_MODEL, GEMINI_API_KEY, BACKUP_LLM_PROVIDER, BACKUP_LLM_MODEL, OPENROUTER_API_KEY

def build_prompt(article):
    return f"""Summarize the following medical research article for a clinical audience (allergists/immunologists).
Structure your response EXACTLY with these sections:
1. **Key Finding** — 3-5 bullets, the most important result
2. **Study Design** — Study type, population, method (brief)
3. **Main Results** — 3-5 bullet points
4. **Clinical Relevance** — Why this matters for allergists/immunologists
5. **Limitations** — Max 2 lines, only if mentioned in abstract

Title: {article.get('title', 'Unknown')}
Journal: {article.get('journal', 'Unknown')}
Abstract:
{article.get('abstract', 'No abstract available')}
"""

async def summarize_article(article):
    prompt = build_prompt(article)
    
    if LLM_PROVIDER == "kku":
        try:
            return await _call_kku(prompt)
        except Exception as e:
            logging.error(f"KKU API failed: {e}")
            if BACKUP_LLM_PROVIDER == "openrouter":
                logging.info("Falling back to OpenRouter...")
                return await _call_openrouter(prompt)
                
    elif LLM_PROVIDER == "openrouter":
        try:
            return await _call_openrouter(prompt)
        except Exception as e:
            logging.error(f"OpenRouter API failed: {e}")
            
    return "Summary unavailable. (LLM Generation Failed)"

async def _call_kku(prompt: str):
    if not KKU_API_KEY:
        raise ValueError("KKU_API_KEY is not set")
        
    url = "https://gen.ai.kku.ac.th/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {KKU_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": LLM_MODEL,
        "messages": [
            {"role": "system", "content": "You are an allergy and immunology research assistant."},
            {"role": "user", "content": prompt}
        ],
        "stream": False,
        # "temperature": 0.2
    }
    async with httpx.AsyncClient() as client:
        resp = await client.post(url, headers=headers, json=payload, timeout=30.0)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()

async def _call_gemini(prompt: str):
    if not GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY is not set")
        
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{LLM_MODEL}:generateContent?key={GEMINI_API_KEY}"
    payload = {
        "contents": [{
            "parts": [{"text": prompt}]
        }],
        "generationConfig": {
            "temperature": 0.2
        }
    }
    async with httpx.AsyncClient() as client:
        resp = await client.post(url, json=payload, timeout=30.0)
        resp.raise_for_status()
        data = resp.json()
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        except (KeyError, IndexError):
            raise Exception("Unexpected Gemini API response format")

async def _call_openrouter(prompt: str):
    if not OPENROUTER_API_KEY:
        raise ValueError("OPENROUTER_API_KEY is not set")
        
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "HTTP-Referer": "https://journal-reader.local",
        "X-Title": "Journal Reader Bot"
    }
    payload = {
        "model": BACKUP_LLM_MODEL,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.2
    }
    async with httpx.AsyncClient() as client:
        resp = await client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload, timeout=30.0)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
